package com.project.studyPlannerAndLearningEnvironment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudyPlannerAndLearningEnvironmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
