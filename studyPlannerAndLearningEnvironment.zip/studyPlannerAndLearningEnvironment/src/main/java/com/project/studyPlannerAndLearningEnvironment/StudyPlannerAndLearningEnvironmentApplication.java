package com.project.studyPlannerAndLearningEnvironment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudyPlannerAndLearningEnvironmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudyPlannerAndLearningEnvironmentApplication.class, args);
	}

}
